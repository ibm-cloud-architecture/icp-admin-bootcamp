helm delete --tls datapower-gw1 --purge
