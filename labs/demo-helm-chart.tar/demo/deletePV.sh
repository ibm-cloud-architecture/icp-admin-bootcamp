kubectl delete pv datapower-cert-volume	
kubectl delete pv datapower-config-volume
kubectl delete pv datapower-local-volume
