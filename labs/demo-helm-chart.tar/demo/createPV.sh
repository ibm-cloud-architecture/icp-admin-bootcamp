cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: PersistentVolume
metadata:
  name: datapower-local-volume
  namespace: datapower
  labels:
    location: local  
spec:
  capacity:
    storage: 5Gi
  accessModes:
    - ReadWriteMany
  nfs:
    server: 172.16.248.35
    path: "/datapower/drouter/local"

EOF

cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: PersistentVolume
metadata:
  name: datapower-config-volume
  namespace: datapower
  labels:
    location: config  
spec:
  capacity:
    storage: 5Gi
  accessModes:
    - ReadWriteMany
  nfs:
    server: 172.16.248.35
    path: "/datapower/drouter/config"

EOF

cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: PersistentVolume
metadata:
  name: datapower-cert-volume
  namespace: datapower
  labels:
    location: cert  
spec:
  capacity:
    storage: 5Gi
  accessModes:
    - ReadWriteMany
  nfs:
    server: 172.16.248.35
    path: "/datapower/drouter/cert"

EOF
