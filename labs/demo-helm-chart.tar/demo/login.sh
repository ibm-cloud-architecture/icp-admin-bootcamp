bx pr login -a https://mycluster.icp:8443 --skip-ssl-validation
